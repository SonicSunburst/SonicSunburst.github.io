SONIC SUNBURST - CGS 2026 WINDOWS DEMO
=====================================

Thanks for playing the Chao Games Showcase (CGS) 2026 demo of Sonic Sunburst!
This demo contains Tropical Tideline and Time Attack mode only.

For game news and information, visit https://sonicsunburst.github.io/.

REQUIREMENTS
------------

* OS: Windows 10 or 11, 64-bit
* CPU: Dual-core, around 2 GHz
* Memory: 4 GB RAM
* Graphics: Integrated or dedicated GPU with DirectX 11 support
* Storage: 500 MB free

These are provisional targets, not measured minimums for every stage or PC.
Performance depends on your hardware, graphics drivers, and game settings.

RUNNING THE GAME
----------------

Double-click SonicSunburst_CGS2026.exe. This encrypted single-file build
unpacks its game data to a temporary folder while it runs.

SAVES AND SETTINGS
------------------

The game uses Save_<slot>.dyson files and settings.dyson for save slots and
settings. Back up these files before deleting or replacing game data.

TROUBLESHOOTING
---------------

If the game does not start, check whether Windows Security or another antivirus
has blocked the executable. When reporting a problem, include your Windows
version, CPU, graphics hardware, and the exact error message.
